import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angularapp';
  name: string = "saquib";
  persons = ["saquib", "umer", "gervasio"]
  phonenumber = 9906;
}
